library(testthat)
library(brcdata)

test_check("brcdata")
